/*
 * kalmanStep_initialize.h
 *
 * Code generation for function 'kalmanStep_initialize'
 *
 * C source code generated on: Fri Jan 16 05:24:03 2015
 *
 */

#ifndef __KALMANSTEP_INITIALIZE_H__
#define __KALMANSTEP_INITIALIZE_H__
/* Include files */
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"

#include "rtwtypes.h"
#include "kalmanStep_types.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern void kalmanStep_initialize(void);
#endif
/* End of code generation (kalmanStep_initialize.h) */
