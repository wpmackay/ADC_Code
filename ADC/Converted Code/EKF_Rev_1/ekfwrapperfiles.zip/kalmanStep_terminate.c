/*
 * kalmanStep_terminate.c
 *
 * Code generation for function 'kalmanStep_terminate'
 *
 * C source code generated on: Fri Jan 16 05:24:03 2015
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "kalmanStep.h"
#include "kalmanStep_terminate.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */
void kalmanStep_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (kalmanStep_terminate.c) */
