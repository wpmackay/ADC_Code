/*
 * kalmanStep_initialize.c
 *
 * Code generation for function 'kalmanStep_initialize'
 *
 * C source code generated on: Fri Jan 16 05:24:03 2015
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "kalmanStep.h"
#include "kalmanStep_initialize.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */
void kalmanStep_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/* End of code generation (kalmanStep_initialize.c) */
